package com.example.projectimplementation;

import javafx.event.ActionEvent;
import  javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    private PasswordField pass;

    @FXML
    private TextField user;

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private Label btn;

    @FXML
    protected void SwitchtoAbonnement(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminAbonnement.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoEmpAbonnement(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("abonnements.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoEvenement(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminEvenement.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoEmpEvenement(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("evenements.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoJeux(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminJeux.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoEmpJeux(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("jeux.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoJeton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminJetons.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoEmpJeton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Jetons.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoEmploye(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("GererEmployées.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SwitchtoLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MagicLandLogin.fxml"));
        stage =(Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void Login(ActionEvent event) throws IOException {

        if (user.getText().equalsIgnoreCase("admin0")) {
            if (pass.getText().equalsIgnoreCase("")) {
                SwitchtoAbonnement(event);
            } else {

            }
        } else {
            SwitchtoEmpAbonnement(event);
        }
    }
}