module com.example.projectimplementation {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.projectimplementation to javafx.fxml;
    exports com.example.projectimplementation;
}